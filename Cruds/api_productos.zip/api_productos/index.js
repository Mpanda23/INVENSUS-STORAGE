const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const app = express();

app.use(function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', '*');
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

app.use(bodyParser.json());

const PUERTO = 3000;

const conexion = mysql.createConnection(
    {
        host: 'localhost',
        database: 'invensus_storage',
        user: 'root',
        password: ''
    }
);

app.listen(PUERTO, () => {
    console.log(`Servidor corriendo en el puerto ${PUERTO}`);
});

conexion.connect(error => {
    if (error) throw error;
    console.log('Conexión exitosa a la base de datos');
});

app.get('/', (req, res) => {
    res.send('API');
});

app.get('/productos', (req, res) => {
    const query = 'SELECT * FROM productos;';
    conexion.query(query, (error, resultado) => {
        if (error) return console.error(error.message);

        if (resultado.length > 0) {
            res.json(resultado);
        } else {
            res.json('No hay registros');
        }
    });
});

app.get('/productos/:id', (req, res) => {
    const { id } = req.params;

    const query = `SELECT * FROM productos WHERE idproductos=${id};`;
    conexion.query(query, (error, resultado) => {
        if (error) return console.error(error.message);

        if (resultado.length > 0) {
            res.json(resultado);
        } else {
            res.json('No hay registros');
        }
    });
});

app.post('/productos/agregar', (req, res) => {
    const producto = {
        prod_nombre: req.body.prod_nombre,
        prod_descripcion: req.body.prod_descripcion,
        prod_valor: req.body.prod_valor,
        prod_vencimiento: req.body.prod_vencimiento,
        prod_alerta: req.body.prod_alerta,
        idcategoria: req.body.idcategoria,
        idproveedores: req.body.idproveedores
    };

    const query = 'INSERT INTO productos SET ?';
    conexion.query(query, producto, (error) => {
        if (error) return console.error(error.message);

        res.json('Se insertó correctamente el producto');
    });
});

app.put('/productos/actualizar/:id', (req, res) => {
    const { id } = req.params;
    const { prod_nombre, prod_descripcion, prod_valor, prod_vencimiento, prod_alerta, idcategoria, idproveedores } = req.body;

    const query = `UPDATE productos SET prod_nombre='${prod_nombre}', prod_descripcion='${prod_descripcion}', prod_valor='${prod_valor}', prod_vencimiento='${prod_vencimiento}', prod_alerta='${prod_alerta}', idcategoria='${idcategoria}', idproveedores='${idproveedores}' WHERE idproductos='${id}';`;
    conexion.query(query, (error) => {
        if (error) return console.error(error.message);

        res.json('Se actualizó correctamente el producto');
    });
});

app.delete('/productos/borrar/:id', (req, res) => {
    const { id } = req.params;

    const query = `DELETE FROM productos WHERE idproductos=${id};`;
    conexion.query(query, (error) => {
        if (error) console.error(error.message);

        res.json('Se eliminó correctamente el producto');
    });
});
