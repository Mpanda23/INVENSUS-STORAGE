<?php
function Conectarse()
{
    $Conexion = new mysqli("localhost", "root", "", "invensus_storage");

    if ($Conexion->connect_errno) {
        echo "Problemas en la Conexion " . $Conexion->connect_error;
    } else {
        return $Conexion;
    }
}

// Conectar a la base de datos
$conn = Conectarse();

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Realizar una consulta SQL
$sql = "SELECT idusuarios, usu_nombre, usu_tipoid, usu_identificacion, usu_numerotel, usu_correo, idroles, usu_estado FROM usuarios";
$result = $conn->query($sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vista productos</title>
    <link rel="stylesheet" href="../css/stilosListar.css">
    
</head>
<body> 
  <header>
    <nav class="container">
      <img src="../img/logo.jpg" alt="" height="60px" width="60px">
      <div class="links">
        <a href="" class="social-links">Quienes somos</a>
        <a href="" class="social-links">Historia</a>
        <a href="" class="social-links">Mision / Vision</a>
        <a href="" class="social-links">Metodos de pago</a>
        <a href="" class="social-links">Ubicaciones</a>
      </div>
      <div class="icon">
        <a href="#" target="_blank" class="sm-icono">
          <img src="../img/instagram.png" alt="">
        </a>
        <a href="#" target="_blank" class="sm-icono">
          <img src="../img/twitter.png" alt="">
        </a>
        <a href="#" target="_blank" class="sm-icono">
          <img src="../img/tik-tok.png" alt="">
        </a>
      </div>
    </nav>
  </header> 
  
  <div class="form">
    <a href="" target="_blank" class="regreso">
      <img src="../img/volver.png" alt="">
    </a>
    <div class="sub-form">
      <h2>Lista de Usuarios</h2>
    <table class="tabla">
        <tr>
            <th>ID del Usuario</th>
            <th>Nombre del Usuario</th>
            <th>Tipo de Identificacion</th>
            <th>Numero de Identificacion</th>
            <th>Celular</th>
            <th>Correo electronico</th>
            <th>Rol</th>
            <th>Estado</th>
            <th>Editar</th>
        </tr>
        <?php
        if ($result->num_rows > 0){
          while($row = $result->fetch_assoc()){
            echo "<tr>";
            echo "<td>" . $row["idusuarios"] . "</td>";
            echo "<td>" . $row["usu_nombre"] . "</td>";
            echo "<td>" . $row["usu_tipoid"] . "</td>";
            echo "<td>" . $row["usu_identificacion"] . "</td>";
            echo "<td>" . $row["usu_numerotel"] . "</td>";
            echo "<td>" . $row["usu_correo"] . "</td>";
            echo "<td>" . $row["idroles"] . "</td>";
            echo "<td>" . $row["usu_estado"] . "</td>";
            echo '<td><a href="actualizarUsuario.php?idusuarios=' . $row["idusuarios"] . '">Actualizar</a></td>';
            echo "</tr>";
          }
        }else {
          echo "<tr><td colspan='4'>No hay usuarios registrados.</td></tr>";
      }

      $conn->close();
        ?>
    </table>
    </div>
  </div>
  <footer>
    <p class="texto-final">©Proyecto Sena Invensus Storage 2023</p>
</footer>
</body>
</html>