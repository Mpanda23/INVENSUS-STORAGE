import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { SubcategoriaModel } from '../shared/subcategoria.model'; 
import { SubcategoriaService } from '../shared/subcategoria.service'; 

@Component({
  selector: 'app-lista-subcategorias',
  templateUrl: './lista-subcategorias.component.html',
  
})
export class ListaSubcategoriasComponent implements OnInit {

  subcategorias: Observable<SubcategoriaModel[]> | undefined;

  constructor(private subcategoriaService: SubcategoriaService) { }

  ngOnInit() {
    this.subcategorias = this.subcategoriaService.obtenerSubcategorias();
  }

  borrarSubcategoria(id: string) {
    this.subcategoriaService.borrarSubcategoria(id).subscribe((data: any) => {
      console.log(data);
    });
  }

}
