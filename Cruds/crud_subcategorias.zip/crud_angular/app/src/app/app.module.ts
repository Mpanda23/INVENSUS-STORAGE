import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EditarSubcategoriaComponent } from './editar-subcategoria/editar-subcategoria.component'; // Asegúrate de usar el nombre correcto del componente
import { ListaSubcategoriasComponent } from './lista-subcategorias/lista-subcategorias.component'; // Asegúrate de usar el nombre correcto del componente

import { SubcategoriaService } from './shared/subcategoria.service'; // Asegúrate de usar el nombre correcto del servicio

@NgModule({
  declarations: [
    AppComponent,
    EditarSubcategoriaComponent,
    ListaSubcategoriasComponent, // Asegúrate de agregar el componente de lista de subcategorías
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
  ],
  providers: [
    SubcategoriaService, // Asegúrate de usar el nombre correcto del servicio
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
