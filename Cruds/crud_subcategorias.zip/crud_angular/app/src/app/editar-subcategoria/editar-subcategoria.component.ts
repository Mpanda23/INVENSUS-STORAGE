import { Component, OnInit } from '@angular/core';
import { SubcategoriaService } from '../shared/subcategoria.service'; // Asegúrate de usar el nombre correcto del servicio
import { ActivatedRoute, Router } from '@angular/router';
import { SubcategoriaModel } from '../shared/subcategoria.model'; // Asegúrate de usar el nombre correcto del modelo

@Component({
  selector: 'app-editar-subcategoria',
  templateUrl: './editar-subcategoria.component.html',
  styleUrls: ['./editar-subcategoria.component.css']
})
export class EditarSubcategoriaComponent implements OnInit {

  id = '';
  subcategoria = new SubcategoriaModel("", ""); 

  constructor(
    private subcategoriaService: SubcategoriaService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    this.id = this.route.snapshot.params['id'];
    if (this.id) {
      console.log("EDITAR");
      this.subcategoriaService.obtenerSubcategoriaPorId(this.id).subscribe((data: any[]) => {
        this.subcategoria = data[0];
      }, (error: any) => {
        console.log(error);
      });
    } else {
      console.log("CREAR");
    }
  }

  onSubmit() {
    console.log('onSubmit');

    if (this.subcategoria.idsubcategorias) {
      this.subcategoriaService.actualizarSubcategoria(this.subcategoria).subscribe(data => {
        alert(data);
        this.router.navigate(['/subcategorias']);
      });
    } else {
      console.log('crear');
      this.subcategoriaService.agregarSubcategoria(this.subcategoria).subscribe(data => {
        alert(data);
        this.router.navigate(['/subcategorias']);
      });
    }
  }
}
