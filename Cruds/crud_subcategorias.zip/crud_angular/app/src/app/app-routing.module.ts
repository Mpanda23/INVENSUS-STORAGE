import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EditarSubcategoriaComponent } from './editar-subcategoria/editar-subcategoria.component'; 
import { ListaSubcategoriasComponent } from './lista-subcategorias/lista-subcategorias.component'; 
const routes: Routes = [
  { path: 'subcategorias', component: ListaSubcategoriasComponent },
  { path: 'subcategorias/editar/:id', component: EditarSubcategoriaComponent },
  { path: 'subcategorias/agregar', component: EditarSubcategoriaComponent },
  { path: '**', redirectTo: '/subcategorias', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
