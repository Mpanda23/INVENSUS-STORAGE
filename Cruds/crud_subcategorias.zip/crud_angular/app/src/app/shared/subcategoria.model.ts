export class SubcategoriaModel {

  constructor(
    public idsubcategorias: string,
    public subc_nombre: string,
    public idcategoria: string = ""
  ) { }

}
