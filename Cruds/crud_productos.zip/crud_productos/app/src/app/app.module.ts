import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EditarProductoComponent } from './editar-producto/editar-producto.component'; 
import { ListaProductosComponent } from './lista-productos/lista-productos.component'; 

import { ProductoService } from './shared/producto.service';
import { InicioComponent } from './inicio/inicio.component'; 
@NgModule({
  declarations: [
    AppComponent,
    EditarProductoComponent,
    ListaProductosComponent,
    InicioComponent, 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
  ],
  providers: [
    ProductoService, 
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
