import { Component, OnInit } from '@angular/core';
import { ProductoService } from '../shared/producto.service'; 
import { ActivatedRoute, Router } from '@angular/router';
import { ProductoModel } from '../shared/producto.model'; 

@Component({
  selector: 'app-editar-producto',
  templateUrl: './editar-producto.component.html',
  styleUrls: ['./editar-producto.component.css']
})
export class EditarProductoComponent implements OnInit {

  id = '';
  producto = new ProductoModel("", "", "", "", "", "", "",""); 

  constructor(
    private productoService: ProductoService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    this.id = this.route.snapshot.params['id'];
    if (this.id) {
      console.log("EDITAR");
      this.productoService.obtenerProductoPorId(this.id).subscribe((data: any[]) => {
        this.producto = data[0];
      }, (error: any) => {
        console.log(error);
      });
    } else {
      console.log("CREAR");
    }
  }

  onSubmit() {
    console.log('onSubmit');

    if (this.producto.idproductos) {
      this.productoService.actualizarProducto(this.producto).subscribe(data => {
        alert(data);
        this.router.navigate(['/productos']);
      });
    } else {
      console.log('crear');
      this.productoService.agregarProducto(this.producto).subscribe(data => {
        alert(data);
        this.router.navigate(['/productos']);
      });
    }
  }
}
