import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.component.html',
  styleUrls: ['./inicio.component.css']
})
export class InicioComponent {
  busqueda: string = '';

  constructor(private router: Router) {}

  buscarProductos(): void {
    // Agrega la lógica de búsqueda según tus necesidades
    console.log('Buscando productos:', this.busqueda);
  }

  irAlCrud(): void {
    // Navegar al componente CRUD
    this.router.navigate(['/productos']);
  }
}
