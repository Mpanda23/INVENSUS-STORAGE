import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EditarProductoComponent } from './editar-producto/editar-producto.component'; 
import { ListaProductosComponent } from './lista-productos/lista-productos.component'; 

const routes: Routes = [
  { path: 'productos', component: ListaProductosComponent },
  { path: 'productos/editar/:id', component: EditarProductoComponent },
  { path: 'productos/agregar', component: EditarProductoComponent },
  { path: '**', redirectTo: '/productos', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
