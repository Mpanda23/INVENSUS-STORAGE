const conexion = require('../database/db');
exports.save = (req, res)=>{
    const usu_nombre = req.body.usu_nombre;
    const usu_tipoid = req.body.usu_tipoid;
    const usu_identificacion = req.body.usu_identificacion;
    const usu_numerotel = req.body.usu_numerotel;
    const usu_correo = req.body.usu_correo;
    const usu_contrasena = req.body.usu_contrasena;
    const usu_estado = req.body.usu_estado;
    const idsexo = req.body.idsexo;
    const idroles = req.body.idroles;
    conexion.query('INSERT INTO usuarios SET ?',{usu_nombre:usu_nombre, usu_tipoid:usu_tipoid, usu_identificacion:usu_identificacion, usu_numerotel:usu_numerotel, usu_correo:usu_correo, usu_contrasena:usu_contrasena, usu_estado:usu_estado, idsexo:idsexo, idroles:idroles}, (error, results)=>{
        if(error){
            console.log(error);
        }else{
            res.redirect('/');
        }
    })
   
};

exports.update = (req, res)=>{
    const idusuarios = req.body.idusuarios;
    const usu_nombre = req.body.usu_nombre;
    const usu_tipoid = req.body.usu_tipoid;
    const usu_identificacion = req.body.usu_identificacion;
    const usu_numerotel = req.body.usu_numerotel;
    const usu_correo = req.body.usu_correo;
    const usu_contrasena = req.body.usu_contrasena;
    const usu_estado = req.body.usu_estado;
    const idsexo = req.body.idsexo;
    const idroles = req.body.idroles;
    conexion.query('UPDATE usuarios set ? WHERE idusuarios = ?', [{usu_nombre:usu_nombre, usu_tipoid:usu_tipoid, usu_identificacion:usu_identificacion, usu_numerotel:usu_numerotel, usu_correo:usu_correo, usu_contrasena:usu_contrasena, usu_estado:usu_estado, idsexo:idsexo, idroles:idroles}, idusuarios], (error, results)=>{
        if(error){
            console.log(error);
        }else{
            res.redirect('/');
        }
    })

}